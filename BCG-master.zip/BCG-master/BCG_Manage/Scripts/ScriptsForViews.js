﻿$(function () {
    $("#example1").DataTable();
 
});