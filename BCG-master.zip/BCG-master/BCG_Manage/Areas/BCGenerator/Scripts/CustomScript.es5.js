﻿"use strict";

$(".render-forms").click(function () {
    "use strict";
    //TODO On radio buttons change make something happend

    var ind = $(this).index();
    if (ind === 0) {
        //TODO: add other form generator with curved edges
    } else {
            //TODO: add other form generator with sharp edges
        }
});

$("#btnNext").click(function () {
    var txtBoxValue;
    txtBoxValue = $("#putJS").val();
    console.log(txtBoxValue);
});

