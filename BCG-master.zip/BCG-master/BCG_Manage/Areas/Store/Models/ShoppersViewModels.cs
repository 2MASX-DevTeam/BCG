﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BCG_Manage.Areas.Store.Models
{
    public class ShoppersViewModel
    {


        public HttpPostedFileBase Picture { get; set; }
    }
}