﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BCG_Manage.Models
{
    public class UniqueVisitorsModel
    {
        public string lat { get; set; }

        public string lng { get; set; }
        
        public string country { get; set; }
    }

    public class UserRegistrationsModel
    {

    }

    public class NewOrdersModel
    {

    }
}