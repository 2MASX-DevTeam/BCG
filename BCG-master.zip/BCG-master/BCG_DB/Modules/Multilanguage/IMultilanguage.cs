﻿namespace MultilanguageTools.Modules.Multilanguage
{
    public interface IMultiLanguage
    {
        int Resource { get; set; }
    }
}
